package com.example.ecommerceapp.activities.ecommerceapp.fragments.shopping

import androidx.fragment.app.Fragment
import com.example.ecommerceapp.R

class SearchFragment: Fragment(R.layout.fragment_search) {
}