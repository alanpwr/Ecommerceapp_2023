package com.example.ecommerceapp.activities.ecommerceapp.util

object Constants {
    const val USER_COLLECTION = "user"
}